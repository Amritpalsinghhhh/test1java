class Car extends Vehicle {

    private String bodyStyle = "";
    private boolean automatic;

    public Car(String vin, String make, String model, int year, double price, int mileage, String bodyStyle, boolean automatic) {
        super(vin, make, model, price, mileage, year);
        this.setBodyStyle(bodyStyle);
        this.setAutomatic(automatic);
    }

    public void show() {
        super.show();
        System.out.println("Body style: " + bodyStyle);
    }

    public String getBodyStyle() {
        return bodyStyle;
    }

    public void setBodyStyle(String bodyStyle) {
        this.bodyStyle = bodyStyle;
    }

    public boolean isAutomatic() {
        return automatic;
    }

    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }
}