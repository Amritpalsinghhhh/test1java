class Truck extends Vehicle {

    private int maxLoadWeight = 0;
    private double lengthFT = 0;

    public Truck(String vin, String make, String model, int year, double price, int mileage, int maxLoadWeight,
                 double lengthFT) {
        super(vin, make, model, price, mileage, year);
        this.setMaxLoadWeight(maxLoadWeight);
        this.setLengthFT(lengthFT);
    }

    public void show() {
        super.show();
        System.out.println("Maximum Load Weight: " + maxLoadWeight);
        System.out.println("Length (in feet): " + lengthFT);
    }

    public int getMaxLoadWeight() {
        return maxLoadWeight;
    }

    public void setMaxLoadWeight(int maxLoadWeight) {
        this.maxLoadWeight = maxLoadWeight;
    }

    public double getLengthFT() {
        return lengthFT;
    }

    public void setLengthFT(double lengthFT) {
        this.lengthFT = lengthFT;
    }
}
