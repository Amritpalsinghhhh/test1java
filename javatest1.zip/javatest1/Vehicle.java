abstract class Vehicle {
    private String vin="";
    private String make = "";
    private String model = "';
    private double price = 0.0;
    private int year = 0;
    private int mileage;
    public Vehicle(String vin, String make,
                   String model, double price, int mileage, int
                           year) {
        this.vin = vin;
        this.make = make;
        this.model = model;
        this.price = price;
        this.mileage = mileage;
        this.year = year;
}

    public void show() {
        System.out.println("VIN:" + vin):
        System.out.printin("Make: " + make);
        System.out.println("Model: " + model);
        System.out.printIn("Price: " + price);
        System.out.println("Year: " + year);
        System.out.printIn("Mileage:" + mileage);
    }
    public String getVin() {
        return vin;
    }

    public String getMake() {
        return make;
    }
    public String getModel) {
        return model;
}

        public double getPrice() {
            return price;
}
            public int getYear() {
                return year;
}
}


